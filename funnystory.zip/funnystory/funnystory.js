// A funny story about Joe the Fish

function tellStory() {
    let joe = {
        name: "Joe",
        type: "fish",
        color: "blue",
        hobby: "blowing bubbles"
    };

    console.log(`Once upon a time, there was a ${joe.color} ${joe.type} named ${joe.name}.`);
    console.log(`${joe.name} loved ${joe.hobby} more than anything else in the ocean.`);
    console.log(`One day, while ${joe.name} was ${joe.hobby}, he met a crab named Carl.`);
    console.log(`Carl said, "Hey ${joe.name}, why do you blow so many bubbles?"`);
    console.log(`${joe.name} replied, "Because it's fun and it makes me happy!"`);
    console.log(`Carl laughed and said, "Well, keep blowing those bubbles, ${joe.name}!"`);
    console.log(`And so, ${joe.name} continued to blow bubbles and lived happily ever after.`);
}

tellStory();
